/**
 * SciLedger — Renderizador de PDF do artigo publicado.
 *
 * Fluxo:  Paper (Mongo) ─▶ buildArticleTokens() ─▶ preenche template ─▶ Playwright ─▶ Buffer PDF
 *
 * IMPORTANTE: cada variante tem margens próprias.
 * v2/v3 usam faixas full-bleed, então as margens LATERAIS precisam ser 0
 * (a classe .bleed compensa internamente com margin/padding de 18–20mm).
 */
import { chromium } from 'playwright';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { buildArticleTokens, type ArticleTokens, type BuildOptions } from './articleViewModel';

export type TemplateVariant = 'v1' | 'v2-1col' | 'v2-2col' | 'v3-1col';

type VariantCfg = { file: string; margin: { top: string; bottom: string; left: string; right: string } };

const VARIANTS: Record<TemplateVariant, VariantCfg> = {
	// clássico: margens laterais normais
	'v1':      { file: 'article-template.tpl.html',          margin: { top:'20mm', bottom:'18mm', left:'17mm', right:'17mm' } },
	// modernos: laterais 0 por causa do full-bleed
	'v2-1col': { file: 'article-template-v2-1col.tpl.html',  margin: { top:'12mm', bottom:'14.5mm', left:'0mm', right:'0mm' } },
	'v2-2col': { file: 'article-template-v2-2col.tpl.html',  margin: { top:'12mm', bottom:'14.5mm', left:'0mm', right:'0mm' } },
	'v3-1col': { file: 'article-template-v3-1col.tpl.html',  margin: { top:'12mm', bottom:'14.5mm', left:'0mm', right:'0mm' } }
};

const TEMPLATE_DIR = path.join(process.cwd(), 'src/lib/server/pdf');

/** Substitui {{TOKEN}} — tokens ausentes viram string vazia (nunca deixa "{{X}}" vazando). */
function fill(tpl: string, tokens: ArticleTokens): string {
	return tpl.replace(/\{\{([A-Z_]+)\}\}/g, (_m, k) => tokens[k] ?? '');
}

/** Cabeçalho/rodapé correm por conta do Chromium — é a ÚNICA forma de ter número de página. */
function furniture(tokens: ArticleTokens, pad: string) {
	const header = `<span style="display:none"></span>`;
	const footer = `
<div style="width:100%;font-family:Inter,Helvetica,Arial,sans-serif;font-size:6.5pt;color:#7C8AA8;padding:0 ${pad};">
  <div style="border-top:.5pt solid #E4E8F0;padding-top:2.4mm;display:flex;justify-content:space-between;align-items:center;">
    <span><i>${tokens.RUNNING_TITLE ?? ''}</i> &nbsp;·&nbsp; ${tokens.DOI} &nbsp;·&nbsp; ${tokens.LICENSE}</span>
    <span><span style="color:#101A3D;font-weight:700;">SciLedger</span> &nbsp;·&nbsp;
      <span class="pageNumber"></span>&thinsp;/&thinsp;<span class="totalPages"></span></span>
  </div>
</div>`;
	return { header, footer };
}

/** Renderiza a partir de tokens já prontos. */
export async function renderTokensToPdf(
	tokens: ArticleTokens,
	variant: TemplateVariant = 'v3-1col'
): Promise<Buffer> {
	const cfg = VARIANTS[variant];
	const tpl = await readFile(path.join(TEMPLATE_DIR, cfg.file), 'utf-8');
	const html = fill(tpl, tokens);
	const pad = cfg.margin.left === '0mm' ? '20mm' : cfg.margin.left;
	const { header, footer } = furniture(tokens, pad);

	const browser = await chromium.launch();
	try {
		const page = await browser.newPage();
		// setContent evita precisar de rota autenticada para o headless browser
		await page.setContent(html, { waitUntil: 'networkidle' });
		await page.emulateMedia({ media: 'print' });
		return await page.pdf({
			format: 'A4',
			printBackground: true,
			displayHeaderFooter: true,
			headerTemplate: header,
			footerTemplate: footer,
			margin: cfg.margin
		});
	} finally {
		await browser.close();
	}
}

/** Atalho: Paper do banco ➜ PDF. */
export async function renderArticlePdf(
	paper: any,
	variant: TemplateVariant = 'v3-1col',
	opts: BuildOptions = {}
): Promise<Buffer> {
	const tokens = buildArticleTokens(paper, opts);
	tokens.RUNNING_TITLE = String(paper?.authorAffiliations?.[0]?.name ?? '') + ' et al.';
	return renderTokensToPdf(tokens, variant);
}
