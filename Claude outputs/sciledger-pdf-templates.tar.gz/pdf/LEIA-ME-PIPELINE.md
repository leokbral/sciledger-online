# Como operar os templates — do banco ao PDF

## Arquitetura em 3 camadas

```
Paper (MongoDB)
      │
      ▼  articleViewModel.ts   ← ÚNICO lugar que conhece o schema
   tokens { TITLE, AUTHORS, ABSTRACT, BODY, … }   (contrato de 28 tokens)
      │
      ▼  renderArticlePdf.ts   ← escolhe a variante + margens + Playwright
   PDF (Buffer)
```

**A regra de ouro:** o template **nunca** conhece o schema. Se `Paper` mudar, você mexe só no
`articleViewModel.ts` — os 4 templates continuam funcionando. Se quiser um 5º template,
basta respeitar os mesmos tokens; nada de código muda.

## Os 4 templates (mesmo contrato, margens diferentes)

| Variante | Arquivo | Margens (top/bottom/left/right) |
|---|---|---|
| `v1` | `article-template.tpl.html` | 20 / 18 / **17** / **17** mm |
| `v2-1col` | `article-template-v2-1col.tpl.html` | 12 / 14.5 / **0** / **0** mm |
| `v2-2col` | `article-template-v2-2col.tpl.html` | 12 / 14.5 / **0** / **0** mm |
| `v3-1col` | `article-template-v3-1col.tpl.html` | 12 / 14.5 / **0** / **0** mm |

> ⚠️ As laterais **precisam ser 0** nas v2/v3 — é o que permite a faixa navy sangrar até a borda.
> A classe `.bleed` recompõe o respiro internamente. Isso já está codificado em `VARIANTS`.

```ts
const pdf = await renderArticlePdf(paper, 'v3-1col', {
  references: refsFormatadas,     // paper.citations são UUIDs → resolva antes
  verifyQrDataUri: qrDataUri,
  verifyDigest: digestDoLedger
});
```

## Mapeamento: campo do banco → token

| Token | Vem de |
|---|---|
| `TITLE` / `ABSTRACT` / `KEYWORDS` | `paper.title` · `paper.abstract` · `paper.keywords[]` |
| `AUTHORS` / `AFFILIATIONS` | **`paper.authorAffiliations[]`** (snapshot: `name`, `orcid`, `isCorresponding`, `affiliations[]`) |
| `KICKER` | `paper.scopusClassifications[].area` |
| `DOI` / `ARTICLE_ID` | `paper.doi` · `paper.id` |
| `DATE_RECEIVED` | 1ª transição p/ `reviewer assignment` no `statusHistory` (fallback `createdAt`) |
| `DATE_REVISED` | `paper.phaseTimestamps.correctionEnd` |
| `DATE_ACCEPTED` / `DATE_PUBLISHED` | última transição p/ `accepted` / `published` |
| `REVIEW_ROUNDS` | `paper.reviewRound` (ou 2 se existir `phaseTimestamps.round2Start`) |
| `REVIEW_REPORTS` | `paper.peer_review.reviewCount` |
| `REVIEW_MODEL` | `paper.peer_review.reviewType` (`open` → "Open", senão "Double-anonymised") |
| `VERIFY_EVENTS` | `paper.statusHistory.length` |
| `ARTICLE_TYPE` | `paper.hubId ? 'Journal Article' : 'Research Article'` |
| `BODY` | `paper.content` (HTML) |
| `REFERENCES` | `paper.citations[]` — **UUIDs**, precisam ser resolvidos |

Helpers prontos no mapper, ainda não plugados em token (use onde quiser no back matter):
- `buildContributions(paper)` → texto de **Author contributions** a partir de `creditAuthorStatements[]` (CRediT)
- `buildDataAvailability(paper)` → **Data availability** a partir de `supplementaryMaterials[]`

## O que ainda falta resolver (achados reais do seu schema)

1. **`paper.content` precisa sair do DOCX.** Você já tem `mammoth`. Converta **na publicação**
   (não a cada download) e guarde o HTML em `content`. Porém o mammoth devolve `<h1>/<h2>/<p>`
   crus — os templates estilizam `h2.sec` com o chip numerado. Escreva um **normalizador**
   (~30 linhas) que troca `<h2>` por `<h2 class="sec"><span class="n">NN</span>…` e numera
   as seções. Sem isso o corpo sai sem a identidade visual.
2. **`citations[]` são UUIDs.** Popule de um model de citação e formate (APA) antes de passar
   em `opts.references`.
3. **QR de verificação.** Gere um data-URI (lib `qrcode`) apontando para `/verify/<id>`.
   Sem isso o cartão fica com um quadrado vazio.
4. **`volume` e `pages` não existem no schema.** Os tokens estão previstos, mas você precisa
   de metadados de publicação (fascículo/paginação) ou remova-os do template.
5. **`VERIFY_DIGEST`.** Deve vir do hash encadeado do registro editorial — é o elemento que
   sustenta a promessa "tamper-evident". Enquanto não existir, exiba "—" em vez de inventar.

## Quando gerar o PDF

Duas opções — recomendo a **segunda**:

- **Sob demanda** (no clique de download): simples, sempre atualizado, mas gasta ~1–2s de
  Chromium por download.
- **No momento da publicação** (recomendado): renderize uma vez quando o paper vai para
  `published`, guarde o arquivo e sirva estático. O PDF publicado é um **registro imutável** —
  combina com a tese de ledger, e o download fica instantâneo. Re-renderize só em errata,
  gerando uma nova versão.

## Nota sobre `render2.mjs`
É o script de desenvolvimento (cabeçalho/rodapé fixos, para eu iterar no design).
Em produção use `renderArticlePdf.ts`, que monta o rodapé a partir dos tokens.
Numeração de página **só** existe via `footerTemplate` — o Chromium não suporta `counter(page)` em CSS.
