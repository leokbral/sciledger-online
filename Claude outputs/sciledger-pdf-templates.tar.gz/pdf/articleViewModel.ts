/**
 * SciLedger — Paper (MongoDB) ➜ ViewModel do PDF
 *
 * Camada ÚNICA de tradução entre o banco e QUALQUER template.
 * Os templates não conhecem o schema; conhecem só os tokens.
 * Mudou o schema? Você mexe só aqui — os 4 templates continuam funcionando.
 */

type Affil = {
	organization?: string; department?: string; city?: string;
	region?: string; country?: string; displayName?: string;
};
type AuthorSnap = {
	name: string; email?: string; orcid?: string;
	isCorresponding?: boolean; affiliation?: string; department?: string;
	affiliations?: Affil[];
};

export type ArticleTokens = Record<string, string>;

const esc = (v: unknown) =>
	String(v ?? '').replace(/[&<>"]/g, (c) => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;' }[c]!));

const fmtDate = (d?: Date | string | null) =>
	d ? new Date(d).toLocaleDateString('en-GB', { day:'2-digit', month:'short', year:'numeric' }) : '—';

/** Rótulo legível de uma afiliação: "Org, Dept, City, Country" */
function affilLabel(a: Affil): string {
	if (a.displayName) return a.displayName;
	return [a.organization, a.department, a.city, a.country].filter(Boolean).join(', ');
}

/** Primeira transição do statusHistory para um dado status. */
function firstTransitionTo(paper: any, status: string): Date | null {
	const h = (paper?.statusHistory ?? []).filter((e: any) => e?.newStatus === status);
	return h.length ? new Date(h[0].createdAt) : null;
}
function lastTransitionTo(paper: any, status: string): Date | null {
	const h = (paper?.statusHistory ?? []).filter((e: any) => e?.newStatus === status);
	return h.length ? new Date(h[h.length - 1].createdAt) : null;
}

/**
 * Autores + afiliações com numeração superscrita.
 * Usa o snapshot `authorAffiliations` (fonte de verdade no momento da publicação);
 * cai para mainAuthor/coAuthors se o snapshot não existir.
 */
function buildAuthors(paper: any) {
	let snaps: AuthorSnap[] = Array.isArray(paper?.authorAffiliations) ? paper.authorAffiliations : [];

	if (!snaps.length) {
		const toSnap = (u: any, corr = false): AuthorSnap => ({
			name: [u?.firstName, u?.lastName].filter(Boolean).join(' ') || u?.name || u?.username || 'Unknown',
			email: u?.email, orcid: u?.orcid, isCorresponding: corr,
			affiliations: u?.affiliation ? [{ organization: u.affiliation }] : []
		});
		const corrId = paper?.correspondingAuthor?.id ?? paper?.correspondingAuthor;
		snaps = [paper?.mainAuthor, ...(paper?.coAuthors ?? [])]
			.filter(Boolean)
			.map((u: any) => toSnap(u, (u?.id ?? u?._id) === corrId));
	}

	// dedupe de afiliações -> índice 1..n
	const index = new Map<string, number>();
	for (const a of snaps) for (const af of a.affiliations ?? []) {
		const k = affilLabel(af); if (k && !index.has(k)) index.set(k, index.size + 1);
	}

	const authorsHtml = snaps.map((a) => {
		const marks = (a.affiliations ?? []).map((af) => index.get(affilLabel(af))).filter(Boolean);
		if (a.isCorresponding) marks.push('*' as any);
		const sup = marks.length ? `<sup>${marks.join(',')}</sup>` : '';
		return `${esc(a.name)}${sup}`;
	}).join(' &nbsp;·&nbsp; ');

	const corr = snaps.find((a) => a.isCorresponding);
	const affilHtml = [
		...[...index.entries()].map(([label, i]) => `<sup>${i}</sup> ${esc(label)}`),
		corr?.email ? `<sup>*</sup> <a href="mailto:${esc(corr.email)}">${esc(corr.email)}</a>` : ''
	].filter(Boolean).join(' &nbsp;·&nbsp; ');

	return { authorsHtml, affilHtml, snaps };
}

/** CRediT (creditAuthorStatements) ➜ parágrafo "Author contributions". */
export function buildContributions(paper: any): string {
	const st = paper?.creditAuthorStatements ?? [];
	if (!st.length) return 'Not provided.';
	return st.map((s: any) => `${esc(s.authorName ?? '')}: ${(s.roles ?? []).map(esc).join(', ')}.`).join(' ');
}

/** supplementaryMaterials ➜ "Data availability". */
export function buildDataAvailability(paper: any): string {
	const m = paper?.supplementaryMaterials ?? [];
	if (!m.length) return 'No additional data associated with this article.';
	return m.map((x: any) => `${esc(x.title)}: <a href="${esc(x.url)}">${esc(x.url)}</a>`).join(' · ');
}

export type BuildOptions = {
	/** Referências já resolvidas (paper.citations é uma lista de UUIDs). */
	references?: string[];
	/** data:image/png;base64,... do QR de verificação. */
	verifyQrDataUri?: string;
	/** Digest do registro editorial (ledger). */
	verifyDigest?: string;
	baseUrl?: string;
};

export function buildArticleTokens(paper: any, opts: BuildOptions = {}): ArticleTokens {
	const base = opts.baseUrl ?? 'https://sciledger.org';
	const { authorsHtml, affilHtml } = buildAuthors(paper);

	const received  = firstTransitionTo(paper, 'reviewer assignment') ?? paper?.createdAt ?? null;
	const accepted  = lastTransitionTo(paper, 'accepted') ?? lastTransitionTo(paper, 'published');
	const published = lastTransitionTo(paper, 'published') ?? paper?.updatedAt ?? null;
	const revised   = paper?.phaseTimestamps?.correctionEnd ?? null;

	const rounds  = paper?.reviewRound ?? (paper?.phaseTimestamps?.round2Start ? 2 : 1);
	const reports = paper?.peer_review?.reviewCount ?? (paper?.peer_review?.reviews?.length ?? 0);
	const events  = (paper?.statusHistory ?? []).length;

	const year = published ? new Date(published).getFullYear() : new Date().getFullYear();
	const kicker = (paper?.scopusClassifications ?? [])
		.map((c: any) => c.area).filter(Boolean).slice(0, 2).join(' · ') || 'Research';

	const citation =
		`${paper?.authorAffiliations?.map((a: any) => a.name).join(', ') ?? ''} (${year}). ` +
		`${esc(paper?.title)}. <i>SciLedger</i>. ${esc(paper?.doi ?? '')}`;

	return {
		TITLE:          esc(paper?.title),
		SUBTITLE:       esc(paper?.subtitle ?? ''),
		KICKER:         esc(kicker),
		ARTICLE_TYPE:   paper?.hubId ? 'Journal Article' : 'Research Article',
		AUTHORS:        authorsHtml,
		AFFILIATIONS:   affilHtml,
		ABSTRACT:       esc(paper?.abstract),
		KEYWORDS:       (paper?.keywords ?? []).map(esc).join(' · '),

		DOI:            esc(paper?.doi ?? '—'),
		ARTICLE_ID:     esc(paper?.id ?? paper?._id),
		VOLUME:         esc(paper?.volume ?? '—'),
		PAGES:          esc(paper?.pages ?? '—'),

		DATE_RECEIVED:  fmtDate(received),
		DATE_REVISED:   fmtDate(revised),
		DATE_ACCEPTED:  fmtDate(accepted),
		DATE_PUBLISHED: fmtDate(published),
		REVIEW_MODEL:   paper?.peer_review?.reviewType === 'open' ? 'Open' : 'Double-anonymised',
		REVIEW_ROUNDS:  String(rounds),
		REVIEW_REPORTS: String(reports),
		LICENSE:        'CC BY 4.0',
		YEAR:           String(year),

		// conteúdo já em HTML (mammoth converte o DOCX)
		BODY:           paper?.content ?? '',
		REFERENCES:     (opts.references ?? []).map((r) => `<li>${r}</li>`).join('\n'),
		CITATION:       citation,

		VERIFY_URL:     `${base.replace(/^https?:\/\//, '')}/verify/${esc(paper?.id ?? paper?._id)}`,
		VERIFY_QR:      opts.verifyQrDataUri ?? '',
		VERIFY_DIGEST:  esc(opts.verifyDigest ?? '—'),
		VERIFY_EVENTS:  String(events)
	};
}
